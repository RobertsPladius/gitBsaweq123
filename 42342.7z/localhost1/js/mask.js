$(document).ready(function(){
    $('#passport').mask('00 00 000000');
    $('#phone').mask('+7 (000) 000-00 00');
    $('#card').mask('0000 0000 0000 0000');
    $('#code').mask('000');
    $('#card_date').mask('00/00');
  });